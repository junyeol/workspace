package class03; 
//package : class들을 보관하는 단위
//class03이라는 이름의 class 보관함이 있다


public class Test01 {
// public : 공개범위를 의미함. <-> private
//			모두에게 공개 <-> 모두에게 은닉
//			java를 처음개발한 사람들은 "모든 개발자들에게 널리 이롭게 할 코드"
//			java는 기본적으로 공개정책(public<-> C언어 기본적으로 정보은닉체제
// class : java의 기본단위
// Test01이라는 이름의 class 파일이 공개적으로 사용할수있게 되어있다.
// 클래스명 규칙
// 대문자로 시작 <-> 메서드, 변수,... 소문자로 시작
	
	public static void main(String[] args) {
		// static : "객체와 무관하게"
		// void : 無
		// void main(String[]args)
		// output 함수명(input)
		// : input으로 String[] args를 가지고
		// main 기능의 함수가
		// 객체와 무관하게 공개적으로 존재한다.
		
	}

}
