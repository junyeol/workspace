package class03;

public class Test02 {
	public static void main(String[] args) {
		// 대용량 "데이터"를 쉽게 다룰 수 있다는 장점
		// 대이터를 저장하려면 데이터가 저장하려는 공간이 먼저 필요하다.
		// ==변수
		int num;
		// 메모리에 공간(크기)이 생김
		// 그공간에 대한 주소가 할당됨
		// 그 주소에 이름을 붙여줌 == 변수명
		num =123;
		System.out.println(num);//줄바꿈을 기본제공해줌
		
		double data=3.14;
		System.out.print(data);// 줄바꿈 x
		//함수
		//println
		//input을 console에 보여주는 함수
	}
}
