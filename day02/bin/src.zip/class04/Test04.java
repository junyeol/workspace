package class04;

public class Test04 {
	public static void main(String[] args) {
//		1~10까지의 정수를 역순으로 출력해주세요
//		ex)10 9 8 7...1
		//for문으로하기
		//i를 10부터 시작
		//i가 0보다 크다
		//i++이 아니라 i--로
		System.out.println("1~10까지의 정수를 역순으로 출력");
		for(int i=10;i>0;i--) {
			
				System.out.print(i);
			}

		
	}
}
