package class04;

public class Test01 {
	public static void main(String[] args) {
//		for(초기식;  조건식; 증감식) {
//			수행할문장;
//		}
	
		for(int i=0; i<5 ; i++) {
			System.out.println("i="+i);;
		}
	
	
	
	}
}
