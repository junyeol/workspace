package class04;


public class Test06 {
	public static void main(String[] args) {

		if(num<collect) {
			System.out.println("up");
			min=num;
		}

	
		
		
	}
}	
