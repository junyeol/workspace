package class01;

public class Test01 {
	public static void main(String[] args) {
		
		
		//반복되는 문장이 있을때
		//달라지는 부분을 변수로 둔다.
		
		
		//ctrl+c,v --->>어?똑같네 반복인가?
	 	for(int a=2;a<=9;a++) {
			//8번 수행됩니다.
			for(int i=1;i<=9;i++){
				//8x9번 수행됩니다.
			System.out.println(a+"x"+i+"=" +(a * i));
			}
			System.out.println("---------------------");
		}
	//내가 원하는 코드. 어디에 넣어야할까
		//1.뉘앙스 파악
		//2.반복문 코드 깊이마다 수행횟수 파악
		
		
		
		
		
		
		
		
		
	}
}
