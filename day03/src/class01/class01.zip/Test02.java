package class01;

public class Test02 {
	public static void main(String[] args) {
		
		
//		for(int a=0;a<3;a++) {
//		for(int i=0;i<5;i++) {
//		System.out.print("*");
//		}
//		System.out.println();
//		}
		
	 	for(int a=0;a<5;a++) {
			//어쨋든 5줄 찍을거야
		for(int i=0; i<=a;i++) {
			//별을 가로로 얼마나 찍을지는 모르지만
			System.out.print("*");
		}
	}
		
		
//		for(int i=0; i<3; i++) {
//			for(int a=0; a<3-i; a++) {
//				System.out.print("*");
//			}
//			System.out.println();
//		}
		
		
		
	}
}
