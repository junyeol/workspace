package class05;

public class Test {
	public static void main(String[] args) {
		while(true) {
	          System.out.println(min + "부터 " + max +"까지의 사이값만 넣어주세요.");
	   
	         
	         //while 제대로된 정수를 입력받는지
	         while(true) {
	            num = sc.nextInt();// 정수를 입력받음
	            
	            if(1<=num && num<=100//이 1과 100 사이값이면) {      // 제대로된 정수를 입력받으면
	               break;                  //반복문을 나감
	            }
	         }
	         
	         if(num==collect) {//입력받은 정수와 정답이 같다면
	            break;                     // 반복문을 나감
	         }
	      }
	}
}
