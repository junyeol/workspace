package class05;

import java.util.Scanner;

// 학생부 프로그램
public class Test01 {

	public static void main(String[] args) {

		String[] datas = new String[2];
		Scanner sc=new Scanner(System.in);
		System.out.println("학생부 프로그램");

		datas[0]="티모";
		int cnt=1; // 현재 저장된 학생의 수

		while(true) {
			System.out.println("=== 메 뉴 ===");
			System.out.println("1. 학생추가");
			System.out.println("2. 학생부 전체출력");
			System.out.println("3. 이름으로 검색");
			System.out.println("4. 번호로 검색");
			System.out.println("5. 이름변경");
			System.out.println("0. 프로그램 종료");
			System.out.println("===============");
			System.out.print("메뉴 입력 >> ");
			int menu=sc.nextInt();

			if(menu==0) {
				System.out.println("프로그램이 종료됩니다.");
				break;
			}
			else if(menu==1) { // 학생추가

				if(cnt >= datas.length) { // 저장할수있는 최대로 이미 저장이 되어있는 경우라면
					//저장할수있는(5) 학생의 수가 현재 학생의 수보다 크거나 같다면
					System.out.println("더이상 데이터를 저장할수없습니다!");
					continue;
				}


				// 정말 _____으로 하시겠습니까?
				String name;
				while(true) {
					System.out.print("저장하고싶은 학생의 이름을 입력해주세요. >> ");
					name=sc.next();
					
					System.out.print("정말 "+name+"(으)로 하시겠습니까? (Y/N) >> ");
					String answer=sc.next();
					
					if(answer.equals("Y")) {
	        			 boolean flag=false;//학생부에 name이 없는 상태
	        		 		//기본적으로 사용자가 입력한 name이 학생부에 없는것을 가정
	        		 		//학생부 데이터들을 하나하나 확인하면서
	        		 		//데이터 일치여부를 판단
	        		 for(int i=0;i<cnt;i++) {
	        			 if(name.equals(datas[i])) {
	        				 //사용자가 입력한 name값이
	        				 //학생부 데이터와 일치합니다?
	        				 
	        				 //학생부에 name이 있는 상탱
	        				 flag=true;
	        				 System.out.println();
	     			//내가 이름을 추가할때
//	     			만약 이름이 이미 저장되어있다면
//	     			다시 이름을 입력받도록
	        		 
	        	 }
	        }
	        		 	if(!flag) {
	        		 		break;
	        		 	}
	        	 
	        	 datas[cnt]=name;
					cnt++;

					System.out.println(name+"이(가) 저장되었습니다!");
	         }
			else if(menu==2) { // 학생부 전체출력

				// ☆ 좋은 코드
				if(cnt<=0) { // 보여줄 데이터가 없다면 == 저장된 데이터가 없음
					System.out.println("보여줄 학생 데이터가 없습니다.");
					continue;
				}



				// 1번부터 "저장된 학생의 수"만큼 출력
				System.out.println("=== 학생 목록 ===");
				for(int i=0;i<cnt;i++) { // ★ i<"cnt"
					System.out.println((i+1)+"번 학생 : "+datas[i]);
				}
				System.out.println("===============");
			}
			else if(menu==3) {
				// 이름으로 검색
				
				
				
				
			}
			else if(menu==4) {
				// 번호로 검색 => PK로 검색 == selectOne(getOne)
				// Primary key : 데이터를 식별할 수 있게 해주는 값
				// ex) 주민번호, 학번,...
				// 사용자가 지정하는 것이 아니라, 프로그램에서 부여하는 값
				// 현재 학생부 프로그램에서는 '번호' == PK
				
				//경계값 검사
				if(cnt<=0) {// 학생이 한명도 저장되어있지 않다면
					System.out.println("검색할 학생 데이터가 없습니다");
					continue;//처음으로 돌아가기
				}
				int num;
				while(true) {
					System.out.println("검색할 학생의 번호 입력");
					 num=sc.nextInt();				
					// 사용자가 검색하고싶은 번호를 입력 => 유효성 검사
					
				if(1<=num && num<=cnt) {//제대로 입력했다면 //경계값 검사
					
					//cnt는 1보다 반드시 크거나 같아야함
					//cnt가 0일수도 있음
					break;
					
					}
				System.out.println("올바른 번호를 입력하세요");
				//제대로 입력하라고 안내문구 출력
				}
				//사용자가 입력한 번호에 해당하는 학생의 이름은
				//datas[num-1]입니다
			}
			else if(menu==5) { // 이름변경
                
	            // UPDATE : UPDATE 처리할 대상 데이터가 특정되어있어야함!
	            // ex) 프로필 사진 변경, 닉네임 변경, ...
	            
	            // 이름을 변경할 학생의 번호 입력 >>
	            // PK로 데이터를 특정한 후에 UPDATE를 진행해야함
	            
	            
	            
	            if(cnt<=0) {
	               System.out.println("변경할 학생 데이터가 없습니다!");
	               continue;
	            }
	            
	            int num;
	            while(true) {
	               System.out.print("변경할 학생의 번호 입력 >> ");
	               num=sc.nextInt();
	               if(1<=num && num<=cnt) {
	                  break;
	               }
	               System.out.println("올바른 번호를 입력해주세요!~~");
	            }
	            // PK로 대상을 특정짓는다는 부분이 selectOne와 닮을수밖에 없다!!!!!

				
				
				
				
				
				
			}
			else { // 유효성 검사
				System.out.println("제대로 입력해주세요~~");
			}
		}





	}

}
	}
}