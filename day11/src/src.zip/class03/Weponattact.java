package class03;

public interface Weponattact {

}
