package class02;

public interface PhoneAction {
	void powerOn(); // 메서드 바디가 없다!
	   public abstract void soundUp(); // 추상 메서드
	   public abstract void soundDown();
}
